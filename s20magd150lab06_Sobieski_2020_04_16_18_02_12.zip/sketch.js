// construction of the game ball
var ballX = 200;
var ballY = 350;
var ballD = 30;
var theta = 0;

// movement of the retro ball
var velY = 0.0;
var gravity = 2.0;

//when the ball touches the ground
var gTouch = false // boolean variable
var jHeight = -20; // the height of the ball's bounce
var bounceCount = 0; //the number of bounces the ball takes
var totalBounce = 0; // the total number of bounces the ball takes
function setup() {
  createCanvas(500, 400);
}

function draw() {
  background('#56DBF0');
  fill('#4FF564');
  rect(0, 200, 500, 400);
  fill('#EBCA0C');
  ellipse(420, 50, 80, 80);
  fill('#D1BEFA');
  ellipse(350, 350, 70, 60);
  rect(330, 290, 30, 60);
  ellipse(350, 270, 80, 60);
  fill('#56DBF0');
  ellipse(350, 270, 60, 40);
  bounceBall();
  fill('#FF7005');
  textSize(20);
  text("The number of bounces the ball has gained is..."+bounceCount, 0, 30);
  positive();
}

function bounceBall(){ //shows how high the ball will bounce for the player
  velY = velY + gravity;
  ballY = velY + ballY;
  
  if(ballY +(ballD/2) >= (height/2)){
    ballY = (height/2) - (ballD/2);
    gTouch = true;
  }else{
    gTouch = false;
  }
  
  for(let b = 1; b < 10; b++){
    push();
    translate(ballX, ballY);
    rotate(theta);
    scale(1.3);
  fill('#EB4D0C');
  ellipse(0, 0, ballD+(b*2), ballD+(b*2));
    line(0, 0, 0, 25);
    pop();
  }
  theta += 0.185;
}

function mousePressed(){
 if(gTouch){
   bounce();
 }
}

function bounce(){ //counts the number of bounces the player gets
velY = jHeight;
  bounceCount++;
}

function positive(){
if(bounceCount % 10 == 0){
  text("Good job!!", 120, 80);
}else if(bounceCount > 100){
 text("Game over!", 120, 80);
  noLoop();
}else if(bounceCount > 10 && bounceCount < 20){
  translate(60, 40);
 fill('#9218D6');
  triangle(30, 200, 60, 200, 45, 220);
  fill('#FF00EE');
  triangle(30, 100, 60, 100, 45, 80);
  fill('#0DFFC4');
  triangle(180, 100, 210, 100, 195, 80);
  fill('#FFB30D');
  triangle(180, 200, 210, 200, 195, 220);
}else if(bounceCount > 20 && bounceCount < 30){
 fill('#00F2FA');
  rect(120, 320, 40, 40);
  fill('#FFA00D');
  triangle(120, 330, 120, 350, 110, 340);
  line(130, 360, 130, 380);
  line(150, 360, 150, 380);
  point(125, 330);
  fill('#00DBFA');
  ellipse(140, 350, 20, 30);
}else if(bounceCount > 30 && bounceCount < 40){
  fill(150);
  ellipse(420, 40, 40, 40);
}
}