let landscape;
let sImage;
let aText;//contains the arial font for one of the texts in the program.
let pText;//a variable that will contain the poorich font for one of the text in the program.
let kitty;
let pup;
let x = 0;

function preload(){
 landscape = loadImage('grassland.jpg');// uploads the image of the grasslands into the program.
  sImage = loadImage('golden sun.jpg');
  kitty = loadImage('kitten.jpg');
  pup = loadImage('puppy.jpg');
  aText = loadFont('arial.ttf');
  pText = loadFont('POORICH.TTF');
}

function setup() {
  createCanvas(500, 700);
}

function draw() {
    image(landscape,0,0);
  fill('#0CE80F');
  stroke('#0CE80F');
  rect(0, 620, 500, 110);
  image(sImage,400, 60);
  textFont(aText, 30);
  textAlign(CENTER);
  fill('#F8FF1F');
  noStroke();
  text('The Land of the Golden Sun', 250, 100);
  sImage.resize(100, 100); //resizes the sun image down to a 100*100 size so it's not too big in the sky for the poster.
  image(kitty, 30, 560);
  kitty.resize(100, 100);
  image(pup,330, 500);
  pup.resize(150,150);
  pup.filter(OPAQUE);
  textFont(pText,20);
  textAlign(RIGHT);
  fill('#FF0D2F');
  text('Coming soon to a theater near you.', x, 600);
  x++;
}
